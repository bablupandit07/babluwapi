# whatsapp-api
whatsapp baileys v4

# Install
- npm install
- npm run start

chcek browser localhost:9000
